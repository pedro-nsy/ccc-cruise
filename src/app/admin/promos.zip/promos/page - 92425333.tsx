"use client";
import React from "react";

// Sections (already created in your project)
import Header from "./sections/Header";
import StatsStrip from "./sections/StatsStrip";
import GeneratorForm from "./sections/GeneratorForm";
import FiltersBar from "./sections/FiltersBar";
import ListTable from "./sections/ListTable";
import DetailsDrawer from "./sections/DetailsDrawer";

// Hook (we don't assume exact API; we use safe accessors)
import { useAdminPromos } from "./hooks/useAdminPromos";

export default function AdminPromosPage() {
  const model: any = useAdminPromos();

  // --- Safe reads with fallbacks (never crash if hook shape differs slightly) ---
  const items         = Array.isArray(model?.items) ? model.items : [];
  const loading       = !!model?.loading;

  // Filters: prefer model.filters.*, else try individual keys
  const filters = {
    q:      model?.filters?.q      ?? model?.q      ?? "",
    type:   model?.filters?.type   ?? model?.type   ?? "",
    status: model?.filters?.status ?? model?.status ?? "",
    used:   model?.filters?.used   ?? model?.used   ?? "",
  };

  // Updaters (URL-sync is handled inside the hook if present)
  const setQ      = (v:string) => model?.set ? model.set({ q: v }) : (model.q = v);
  const setType   = (v:string) => model?.set ? model.set({ type: v }) : (model.type = v);
  const setStatus = (v:string) => model?.set ? model.set({ status: v }) : (model.status = v);
  const setUsed   = (v:string) => model?.set ? model.set({ used: v }) : (model.used = v);

  // Trigger search (prefer search(), fall back to fetch() / fetchList())
  const search = () =>
    typeof model?.search === "function"
      ? model.search()
      : typeof model?.fetch === "function"
      ? model.fetch()
      : typeof model?.fetchList === "function"
      ? model.fetchList()
      : undefined;

  // --- Sorting (UI<->API map to avoid hydration mismatches on Created) ---
  const apiSortMap: Record<string, string> = {
    created: "created_at",
    type: "type",
    status: "status",
    code: "code",
    used: "used_count",
    assigned: "assigned_to_name",
  };
  const uiSortMap: Record<string, string> = {
    created_at: "created",
    type: "type",
    status: "status",
    code: "code",
    used_count: "used",
    assigned_to_name: "assigned",
  };

  const currentSortApi: string = model?.sort ?? "created_at";
  const currentDir: "asc" | "desc" = model?.dir === "asc" ? "asc" : "desc";
  const uiSort: "code" | "type" | "status" | "used" | "assigned" | "created" =
    (uiSortMap[currentSortApi] as any) ?? "created";

    // Toggle sort for table headers; map created <-> created_at
  const onTableSort = (k: "code" | "type" | "status" | "used" | "assigned" | "created") => {
    const apiSortMap: Record<string,string> = {
      created: "created_at",
      type: "type",
      status: "status",
      code: "code",
      used: "used_count",
      assigned: "assigned_to_name",
    };
    const apiKey = apiSortMap[k] ?? k;

    const currentSort = (model as any)?.sort ?? "created_at";
    const currentDir  = (model as any)?.dir === "asc" ? "asc" : "desc";
    const nextDir: "asc" | "desc" = currentSort === apiKey ? (currentDir === "asc" ? "desc" : "asc") : "asc";

    const m:any = model;

    // Try many setter shapes to cover any hook signature
    try {
      if (typeof m.setSort === "function" && typeof m.setDir === "function") {
        m.setSort(apiKey); m.setDir(nextDir);
      } else if (typeof m.setSort === "function") {
        m.setSort(apiKey, nextDir);
      } else if (typeof m.set === "function") {
        m.set({ sort: apiKey }); m.set({ dir: nextDir }); m.set({ page: 1 });
      } else {
        // URL fallback so hook can read on next fetch
        const u = new URL(window.location.href);
        u.searchParams.set("sort", apiKey);
        u.searchParams.set("dir", nextDir);
        u.searchParams.set("page", "1");
        window.history.replaceState({}, "", u.toString());
      }
    } catch {}

    // Trigger fetch via any known method
    try {
      if (typeof m.search === "function") m.search();
      else if (typeof m.fetch === "function") m.fetch();
      else if (typeof m.fetchList === "function") m.fetchList();
    } catch {}
  };

  // --- Row actions ---
  const copyCode = async (code: string) => {
    try {
      await navigator.clipboard.writeText(code);
      // If you use toast, you can fire it here.
    } catch {}
  };

  const toggleStatus = (id: string | number, to: "active" | "disabled") => {
    if (typeof model?.toggleStatus === "function") {
      model.toggleStatus(id, to);
    }
  };

  // --- Details drawer state (kept local; hook may also expose helpers) ---
  const [openId, setOpenId] = React.useState<string | number | null>(null);
  const [openRow, setOpenRow] = React.useState<any>(null);
  const [usage, setUsage] = React.useState<any[] | null>(null);
  const [usageLoading, setUsageLoading] = React.useState(false);

  const openDetails = (row: any) => {
    setOpenId(row?.id ?? null);
    setOpenRow(row ?? null);
    setUsage(null);
    if (typeof model?.getUsage === "function") {
      setUsageLoading(true);
      Promise.resolve(model.getUsage(row.id))
        .then((u:any) => setUsage(Array.isArray(u) ? u : []))
        .finally(() => setUsageLoading(false));
    }
  };
  const closeDetails = () => {
    setOpenId(null);
    setOpenRow(null);
    setUsage(null);
    setUsageLoading(false);
  };

  return (
    <main className="mx-auto max-w-5xl px-4 sm:px-6 mt-6 sm:mt-8 space-y-8">
      <Header />

      <StatsStrip stats={model?.stats ?? null} />

      <GeneratorForm
        onCreate={(payload:any) => {
          if (typeof model?.create === "function") {
            model.create(payload).then(() => search?.());
          }
        }}
      />

      <FiltersBar
        q={filters.q}
        type={filters.type}
        status={filters.status}
        used={filters.used}
        setQ={setQ}
        setType={setType}
        setStatus={setStatus}
        setUsed={setUsed}
        onSearch={() => search()}
      />

      <ListTable
        items={items}
        loading={loading}
        onCopy={copyCode}
        onToggleStatus={toggleStatus}
        onOpenDetails={openDetails}
        sort={uiSort}
        dir={currentDir}
        onSort={onTableSort}
      />

      {openId && openRow && (
        <DetailsDrawer
          row={openRow}
          usage={usage}
          usageLoading={usageLoading}
          onClose={closeDetails}
        />
      )}
    </main>
  );
}


