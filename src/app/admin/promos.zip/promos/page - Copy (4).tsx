
  // ---- Sort wiring (UI<->API) ----
  const apiSortMap: Record<string, string> = {
    created: 'created_at',
    type: 'type',
    status: 'status',
    code: 'code',
    used: 'used_count',
    assigned: 'assigned_to_name',
  };
  const uiSortMap: Record<string, string> = {
    created_at: 'created',
    type: 'type',
    status: 'status',
    code: 'code',
    used_count: 'used',
    assigned_to_name: 'assigned',
  };

  // derive UI sort key for header arrows
  const uiSort = uiSortMap[(model as any).sort as string] ?? ((model as any).sort as any);

  // Toggle sort dir when clicking the same key; otherwise start asc.
  const onTableSort = (k: 'code' | 'type' | 'status' | 'used' | 'assigned' | 'created') => {
    const apiKey = apiSortMap[k] ?? k;
    const same   = (model as any).sort === apiKey;
    const next   = same ? (((model as any).dir === 'asc') ? 'desc' : 'asc') : 'asc';

    // Hook-style state update
    if (typeof (model as any).set === 'function') {
      (model as any).set({ sort: apiKey, dir: next, page: 1 });
    }

    // Trigger fetch via whatever name the hook exposes
    const m:any = model as any;
    if (typeof m.search === 'function') m.search();
    else if (typeof m.fetch === 'function') m.fetch();
    else if (typeof m.fetchList === 'function') m.fetchList();
  };


  
  
  // -- Table sort helpers (UI<->API key mapping, SSR/CSR-safe arrows) --
  const toApiSort = (k: any) => (k === "created" ? "created_at" : k);
  const toUiSort  = (k: any) => (k === "created_at" ? "created" : k);

  // What the table uses for its header arrows:
// Toggle sort dir when clicking the same key; otherwise start at 'asc'.
    // Toggle sort for table headers; maps created -> created_at
    // ---- Sort wiring (UI<->API) ----
  const apiSortMap: Record<string, string> = {
    created: 'created_at',
    type: 'type',
    status: 'status',
    code: 'code',
    used: 'used_count',
    assigned: 'assigned_to_name',
  };
  const uiSortMap: Record<string, string> = {
    created_at: 'created',
    type: 'type',
    status: 'status',
    code: 'code',
    used_count: 'used',
    assigned_to_name: 'assigned',
  };

  // derive UI sort key from model.sort (API key) for the table header arrows
// Robust table sort handler: toggles dir when same key, writes URL via model.set, then fetches
  
// Map API <-> UI sort keys so SSR/CSR match and arrows don't hydrate-diff.
// What the table should display for the current model.sort:
// Robust sort handler (works whether the hook exposes setSort or setSortKey / setDir or setDirection)
  // Robust table sort handler: toggles dir when same key, then fetches
  // --- Keep your existing auth guard behavior (redirect if no session) ---
  useEffect(() => {
    let alive = true;
    supabase.auth.getSession().then(({ data }) => {
      const token = data.session?.access_token || "";
      if (!token && alive) window.location.href = "/admin/login";
    });
    return () => { alive = false; };
  }, []);

  // --- Local-only UI state (unchanged) ---
  const [openId, setOpenId] = useState<string | number | null>(null);
  const [openRow, setOpenRow] = useState<Promo | null>(null);
  const [usage, setUsage] = useState<UsageRow[] | null>(null);
  const [usageLoading, setUsageLoading] = useState(false);

  const [genType, setGenType] = useState<""|"early_bird"|"artist"|"staff">("");
  const [qty, setQty] = useState(10);
  const [meta, setMeta] = useState({ name: "", email: "", phone: "", note: "" });
  const [genMsg, setGenMsg] = useState("");

  // ---- Handlers (same UX; now they call the hook methods) ----
  const onSearch = () => {
    model.onSearch(); // writes URL + fetches; keeps ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã¢â‚¬Å“Search-onlyÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â rule
  };

  const copyCode = async (code: string) => {
    try { await navigator.clipboard.writeText(code); toast.success("Code copied"); }
    catch { toast.error("CouldnÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â‚¬Å¾Ã‚Â¢t copy"); }
  };

  const toggleStatus = async (id: string|number, to: "active"|"disabled") => {
    const res = await model.toggleStatus(id, to);
    if (res.ok) {
      toast.success(to === "active" ? "Code enabled" : "Code disabled");
      model.fetchList();
    } else {
      toast.error("Update failed");
    }
  };

  const openDetails = async (row: Promo) => {
    setOpenRow(row); setOpenId(row.id); setUsage(null); setUsageLoading(true);
    const { ok, items } = await model.loadUsage(row.id);
    setUsage(ok ? items : []);
    if (!ok) toast.error("Failed to load history");
    setUsageLoading(false);
  };
  const closeDetails = () => { setOpenId(null); setOpenRow(null); setUsage(null); };

  const createCodes = async (e: React.FormEvent) => {
    e.preventDefault();
    setGenMsg("");
    if (!genType) { setGenMsg("Choose a promo type."); return; }
    const payload = {
      type: genType, qty,
      assigned_to_name: meta.name || null,
      assigned_email:  meta.email || null,
      assigned_phone:  meta.phone || null,
      note:            meta.note || null,
    };
    const { ok, data } = await model.createCodes(payload);
    if (!ok) {
      setGenMsg(data?.error || "Failed to create codes.");
      toast.error("Create failed");
      return;
    }
    const created = data?.created ?? 0;
    setGenMsg(`Created ${created} codes.`);
    toast.success(`Created ${created} code${created === 1 ? "" : "s"}`);
    model.fetchList();
  };

  // Visuals unchanged
  const filtered = useMemo(() => model.items, [model.items]);

  return (
    <main className="mx-auto max-w-5xl space-y-8 mt-8">
      <Toaster position="top-right" />

      <Header />

      <StatsStrip stats={model.stats} />

      <GeneratorForm
        genType={genType} setGenType={setGenType}
        qty={qty} setQty={setQty}
        meta={meta} setMeta={setMeta}
        genMsg={genMsg}
        onSubmit={createCodes}
      />
<FiltersBar
  q={model.filters.q}
  type={model.filters.type}
  status={model.filters.status}
  used={model.filters.used}
  setQ={(v) => model.setFilters({ q: v })}
  setType={(v) => model.setFilters({ type: v as any })}
  setStatus={(v) => model.setFilters({ status: v as any })}
  setUsed={(v) => model.setFilters({ used: v as any })}
  onSearch={onSearch}
/>


            <ListTable
  items={filtered}
  loading={model.loading}
  onCopy={copyCode}
  onToggleStatus={toggleStatus}
  onOpenDetails={openDetails}
  sort={uiSort}
  dir={(model as any).dir}
  onSort={onTableSort}
/>

      {openId && openRow && (
        <DetailsDrawer
          row={openRow}
          usage={usage}
          usageLoading={usageLoading}
          onClose={closeDetails}
        />
      )}
    </main>
  );
}

