﻿export default function Pagination() {
  return null; // Step 5A: no pagination UI yet
}
