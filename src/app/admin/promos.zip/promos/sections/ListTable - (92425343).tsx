"use client";
import React from "react";
import { TypeChip, StatusChip } from "./chips";
import { fmtDate, yesNo } from "./format";

type SortKey = "code" | "type" | "status" | "used" | "assigned" | "created";
type SortDir  = "asc" | "desc";

type Row = {
  id: string | number;
  code: string;
  type: "early_bird" | "artist" | "staff";
  status: "active" | "disabled" | "reserved" | "consumed";
  used_count: number;
  assigned_to_name: string | null;
  created_at: string | null;
};

export default function ListTable({
  items,
  loading,
  sort,
  dir,
  onSort,
  onCopy,
  onToggleStatus,
  onOpenDetails,
}: {
  items: Row[];
  loading: boolean;
  sort: SortKey;
  dir: SortDir;
  onSort: (key: SortKey) => void;
  onCopy: (code: string) => void;
  onToggleStatus: (id: string | number, to: "active" | "disabled") => void;
  onOpenDetails: (row: Row) => void;
}) {
  return (
    <div className="rounded-2xl border bg-white overflow-hidden">
      <table className="w-full table-fixed">
        <colgroup><col className="w-[22%]" /><col className="w-[14%]" /><col className="w-[12%]" /><col className="w-[8%]" /><col className="w-[22%] md:table-column hidden" /><col className="w-[12%] md:table-column hidden" /><col className="w-[10%]" /></colgroup>
                <thead className="bg-neutral-50 border-b">
          <tr className="text-neutral-700 text-sm">
            <Th label="Code"      k="code"     sort={sort} dir={dir} onSort={onSort} className="text-left" />
            <Th label="Type"      k="type"     sort={sort} dir={dir} onSort={onSort} />
            <Th label="Status"    k="status"   sort={sort} dir={dir} onSort={onSort} />
            <Th label="Used"      k="used"     sort={sort} dir={dir} onSort={onSort} />
            <Th label="Assigned to" k="assigned" sort={sort} dir={dir} onSort={onSort} className="hidden md:table-cell" />
            <Th label="Created"   k="created"  sort={sort} dir={dir} onSort={onSort} className="hidden md:table-cell" />
            <th className="text-center px-3 py-2">Actions</th>
          </tr>
        </thead>
        <tbody className="text-sm">
          {loading ? (
            <tr>
              <td colSpan={7} className="px-4 py-6 text-center text-neutral-600">Loading…</td>
            </tr>
          ) : items.length === 0 ? (
            <tr>
              <td colSpan={7} className="px-4 py-6 text-center text-neutral-600">No codes match your filters. Try adjusting search or filters.</td>
            </tr>
          ) : (
            items.map((p) => {
              const assigned = p.assigned_to_name && p.assigned_to_name.trim().length > 0 ? p.assigned_to_name : "—";
              const created  = p.created_at ? fmtDate(p.created_at) : "—";
              return (
                <tr key={p.id} className="border-t">
                  {/* Code + Copy */}
                  <td className="px-4 py-4">
                    <div className="flex items-center gap-3">
                      <div className="font-medium text-neutral-800">{p.code}</div>
                      <button
                        onClick={() => onCopy(p.code)}
                        className="text-blue-600 hover:text-blue-700 text-xs underline-offset-4 hover:underline"
                        aria-label={`Copy ${p.code}`}
                        title="Copy"
                      >
                        Copy
                      </button>
                    </div>
                  </td>

                  {/* Type */}
                  <td className="text-center"><TypeChip type={p.type} /></td>

                  {/* Status */}
                  <td className="text-center"><StatusChip status={p.status} /></td>

                  {/* Used */}
                  <td className="text-center">
                    <span className="inline-flex items-center rounded-full border px-2 py-0.5 text-xs bg-white">
                      {yesNo(p.used_count > 0)}
                    </span>
                  </td>

                  {/* Assigned to (hidden on mobile) */}
                  <td className="hidden md:table-cell text-center">
                    <span className="inline-block max-w-[16rem] whitespace-normal break-words">{assigned}</span>
                  </td>

                  {/* Created (hidden on mobile) */}
                  <td className="hidden md:table-cell text-center">
                    <span className="text-xs text-neutral-600">{created}</span>
                  </td>

                  {/* Actions */}
                  <td className="pr-4">
                    <div className="flex items-center justify-end md:justify-center gap-2">
                      {p.status === "active" ? (
                        <button className="text-blue-600 hover:text-blue-700 text-xs whitespace-nowrap" onClick={() => onToggleStatus(p.id, "disabled")}>Disable</button>
                      ) : (
                        <button className="text-blue-600 hover:text-blue-700 text-xs whitespace-nowrap" onClick={() => onToggleStatus(p.id, "active")}>Enable</button>
                      )}
                      <button
                        className="inline-flex items-center justify-center rounded-full border border-neutral-300 p-1.5 hover:border-neutral-400"
                        aria-label="Details"
                        title="Details"
                        onClick={() => onOpenDetails(p)}
                      >
                        <span aria-hidden className="text-neutral-600">ⓘ</span>
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })
          )}
        </tbody>
      </table>
    </div>
  );
}

function Th({
  label, k, sort, dir, onSort, className = "",
}: {
  label: string;
  k: SortKey;
  sort: SortKey;
  dir: SortDir;
  onSort: (k: SortKey) => void;
  className?: string;
}) {
  const isActive   = sort === k;
  const arrow      = !isActive ? "▵▿" : dir === "asc" ? "▲" : "▼";
  const arrowClass = isActive ? "text-neutral-700" : "text-neutral-300";

  return (
    <th className={`text-center py-2 ${className}`}>
      <button type="button" onClick={() => onSort(k)} className="inline-flex items-center gap-1 hover:text-neutral-800">
        <span>{label}</span>
        <span className={`text-[10px] leading-none ${arrowClass}`} aria-hidden>{arrow}</span>
      </button>
    </th>
  );
}



