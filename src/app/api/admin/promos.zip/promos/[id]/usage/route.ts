import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/adminAuth";
import { supabaseServer } from "@/lib/supabase-server";

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const gate = await requireAdmin(req);
  if ("error" in gate) return gate.error;

  const supabase = supabaseServer();
  const { data, error } = await supabase
    .from("promo_usages")
    .select(`
      id,
      promo_code_id,
      booking_ref,
      traveler_id,
      status,
      reserved_at,
      consumed_at,
      released_at,
      created_at,
      updated_at,
      actor_user_id,
      actor_email,
      traveler:travelers!promo_usages_traveler_id_fkey (
        first_name,
        last_name
      )
    `)
    .eq("promo_code_id", params.id)
    .order("created_at", { ascending: false });

  if (error) return NextResponse.json({ ok: false, error: error.message }, { status: 500 });

  const items = (data || []).map((row: any) => {
    const t = row?.traveler || null;
    const traveler_name = t
      ? [t.first_name, t.last_name].filter(Boolean).join(" ").trim() || null
      : null;
    const { traveler, ...rest } = row || {};
    return { ...rest, traveler_name };
  });

  return NextResponse.json({ ok: true, items });
}
