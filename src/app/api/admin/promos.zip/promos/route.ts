import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

export const dynamic = "force-dynamic";
export const revalidate = 0;

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

type SortKey = "created" | "code" | "type" | "status" | "assigned";

// helper: count(*) with head=true
async function countCodes(filters: (q: ReturnType<typeof supabase.from>) => ReturnType<typeof supabase.from>) {
  let q: any = supabase.from("promo_codes").select("id", { head: true, count: "exact" });
  q = filters(q);
  const { count, error } = await q;
  if (error) throw new Error(error.message);
  return count || 0;
}

export async function GET(req: Request) {
  try {
    const u = new URL(req.url);
    const sp = u.searchParams;

    const qRaw = (sp.get("q") || "").trim();
    const q = qRaw ? "%" + qRaw + "%" : "";
    const type = sp.get("type") && sp.get("type") !== "all" ? sp.get("type")! : "";
    let status = sp.get("status") && sp.get("status") !== "all" ? sp.get("status")! : "";
    if (status === "disabled") status = "archived"; // bwd-compat
    const used = sp.get("used") && sp.get("used") !== "all" ? sp.get("used")! : "";

    const sort: SortKey = (sp.get("sort") as SortKey) || "created";
    const dirAsc = sp.get("dir") === "asc";
    const page = Math.max(1, parseInt(sp.get("page") || "1", 10));
    const limit = Math.max(1, parseInt(sp.get("limit") || "25", 10));
    const from = (page - 1) * limit;
    const to = from + limit - 1;

    const sortMap: Record<SortKey, string> = {
      created: "created_at",
      code: "code",
      type: "type",
      status: "status",
      assigned: "assigned_to_name",
    };

    // --- LIST (paged) ---
    let list = supabase
      .from("promo_codes")
      .select("id, code, type, status, assigned_to_name, created_at, created_by_user_id, created_by_email", { count: "exact" });

    if (q) list = list.or("code.ilike." + q + ",assigned_to_name.ilike." + q);
    if (type) list = list.eq("type", type);
    if (status) list = list.eq("status", status);
    if (used === "yes") list = list.eq("status", "consumed");
    if (used === "no")  list = list.neq("status", "consumed");

    list = list.order(sortMap[sort] || "created_at", { ascending: dirAsc, nullsFirst: false }).range(from, to);

    const { data: items, count: total, error: listErr } = await list;
    if (listErr) return NextResponse.json({ ok: false, error: "QUERY_FAILED", detail: listErr.message }, { status: 500 });
    // Derive effective status for items in this page from promo_usages (reserved/consumed)
    const ids = (items || []).map((it:any) => it.id).filter(Boolean);
    let derived: Record<string, "reserved"|"consumed"> = {};
    if (ids.length) {
      const { data: uses, error: usesErr } = await supabase
        .from("promo_usages")
        .select("promo_code_id,status")
        .in("promo_code_id", ids as any)
        .in("status", ["reserved","consumed"]);
      if (!usesErr && Array.isArray(uses)) {
        for (const u of uses as any[]) {
          const k = String(u.promo_code_id);
          // consumed wins over reserved
          if (u.status === "consumed") { derived[k] = "consumed"; continue; }
          if (!derived[k]) derived[k] = "reserved";
        }
      }
    }
    const itemsOut = (items || []).map((it:any) => {
      const k = String(it.id);
      let nextStatus = it.status;
      if (it.status !== "archived") {
        if (derived[k] === "consumed") nextStatus = "consumed";
        else if (derived[k] === "reserved") nextStatus = "reserved";
      }
      return { ...it, status: nextStatus };
    });


    // --- GLOBAL STATS (per type) ---
    const types = ["early_bird", "artist", "staff"] as const;

    // caps (active row)
    const { data: capsRows, error: capErr } = await supabase.from("promo_caps_active").select("type, cap");
    if (capErr) return NextResponse.json({ ok:false, error:"STATS_CAPS_FAILED", detail:capErr.message }, { status:500 });
    const caps: Record<string, number | null> = Object.fromEntries(types.map(t => [t, null]));
    (capsRows || []).forEach((r: any) => { if (r?.type) caps[r.type] = r.cap == null ? null : Number(r.cap); });

    const created: Record<string, number>  = Object.fromEntries(types.map(t => [t, 0]));
    const consumed: Record<string, number> = Object.fromEntries(types.map(t => [t, 0]));
    const inCap:   Record<string, number>  = Object.fromEntries(types.map(t => [t, 0]));

    await Promise.all(types.map(async (t) => {
      const [cAll, cCons, cInCap] = await Promise.all([
        countCodes(q => q.eq("type", t)),
        countCodes(q => q.eq("type", t).eq("status", "consumed")),
        countCodes(q => q.eq("type", t).neq("status", "archived")),
      ]);
      created[t]  = cAll;
      consumed[t] = cCons;
      inCap[t]    = cInCap; // active + reserved + consumed
    }));

    return NextResponse.json({
      ok: true,
      items: itemsOut || [],
      total: total || 0,
      stats: { created, consumed, in_cap: inCap, caps }
    });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: "UNEXPECTED", detail: e?.message || String(e) }, { status: 500 });
  }
}

// === Generator helpers to match DB regex ===
// Safe alphabet excludes I, O, 0, 1
const CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

function randSafe(len: number) {
  let s = "";
  for (let i = 0; i < len; i++) s += CHARS[Math.floor(Math.random() * CHARS.length)];
  return s;
}
function prefixForType(t: string) { return t === "early_bird" ? "EL" : t === "artist" ? "AR" : "ST"; }
function suffixForType(t: string) { return t === "early_bird" ? "B"  : t === "artist" ? "T"  : "F"; }

async function countInCap(type: string) {
  let q: any = supabase.from("promo_codes").select("id",{ head:true, count:"exact" }).eq("type", type).neq("status","archived");
  const { count, error } = await q;
  if (error) throw new Error(error.message);
  return count || 0;
}

export async function POST(req: Request) {
  /*__ACTOR_PARSE__*/
  let actorEmail: string | null = null;
  let actorId: string | null = null;
  try {
    const auth = req.headers.get("authorization") || "";
    const token = auth.split(" ")[1] || "";
    const b64 = token.split(".")[1];
    if (b64) {
      const json = JSON.parse(Buffer.from(b64.replace(/-/g,"+").replace(/_/g,"/"), "base64").toString("utf8"));
      actorEmail = json?.email ?? null;
      actorId = json?.sub ?? json?.user_metadata?.sub ?? null;
    }
  } catch {}

  try {
    const body = await req.json().catch(()=> ({}));
    const type = (body?.type || "").trim();
    const quantity = Math.max(1, parseInt(String(body?.quantity || "1"), 10));
    const assigned_to_name = (body?.assigned_to_name ?? "").toString().trim() || null;

    if (!["early_bird","artist","staff"].includes(type)) {
      return NextResponse.json({ ok:false, code:"BAD_TYPE", message:"Type must be early_bird, artist, or staff." }, { status:400 });
    }
    if (!Number.isFinite(quantity) || quantity < 1) {
      return NextResponse.json({ ok:false, code:"BAD_QUANTITY", message:"Quantity must be a positive integer." }, { status:400 });
    }
    if (quantity > 20) {
      return NextResponse.json({ ok:false, code:"BAD_QUANTITY", message:"Bulk is limited to 20 codes at a time." }, { status:400 });
    }

    // Read cap (null = no cap)
    const { data: capsRows, error: capErr } = await supabase.from("promo_caps_active").select("type, cap").eq("type", type).maybeSingle();
    if (capErr) return NextResponse.json({ ok:false, code:"CAPS_READ_FAILED", message:capErr.message }, { status:500 });

    const cap = capsRows?.cap ?? null;
    if (cap !== null) {
      const inCap = await countInCap(type);
      const remaining = Math.max(0, cap - inCap);
      if (quantity > remaining) {
        return NextResponse.json({
          ok:false, code:"OVER_CAP",
          message: "Cap reached for " + type.replace("_"," ") + " (" + cap + "). Remaining: " + remaining + ". Reduce quantity or archive codes.",
          cap, remaining
        }, { status:409 });
      }
    }

    // Create codes with format:
    // EL/AR/ST + [A-HJ-NP-Z2-9]{2} + "-" + [A-HJ-NP-Z2-9]{3} + B/T/F
    const batch: any[] = [];
    const pfx = prefixForType(type);
    const sfx = suffixForType(type);
    const seen = new Set<string>();

    for (let i = 0; i < quantity; i++) {
      let code = "";
      do {
        code = pfx + randSafe(2) + "-" + randSafe(3) + sfx;
      } while (seen.has(code));
      seen.add(code);

      const row: any = { code, type, status: "active" };
      if (assigned_to_name) row.assigned_to_name = assigned_to_name;
      batch.push(row);
    }

    const { data: ins, error: insErr } = await supabase
      .from("promo_codes")
      .insert(batch)
      .select("id, code, type, status, assigned_to_name");

    if (insErr) {
      return NextResponse.json({ ok:false, code:"CREATE_FAILED", message:insErr.message }, { status:500 });
    }

    return NextResponse.json({ ok:true, created: ins || [], count: (ins||[]).length });
  } catch (e:any) {
    return NextResponse.json({ ok:false, code:"UNEXPECTED", message: e?.message || String(e) }, { status:500 });
  }
}
