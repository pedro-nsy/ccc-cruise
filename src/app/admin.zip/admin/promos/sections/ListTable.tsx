import { Info, ChevronUp, ChevronDown } from "lucide-react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { TypeChip, StatusChip } from "./chips";

type SortKey = "created" | "code" | "type" | "status" | "assigned";

export default function ListTable({
  items,
  loading,
  onCopy,
  onToggleStatus,
  onOpenDetails,
  total,
}: {
  items: Array<{
    id: string | number;
    code: string;
    type: "early_bird" | "artist" | "staff";
    status: "active" | "archived" | "reserved" | "consumed";
    used_count: number;
    assigned_to_name: string | null;
    created_at?: string;
  }>;
  loading: boolean;
  onCopy: (code: string) => void;
  onToggleStatus: (id: string | number, to: "active" | "archived") => void;
  onOpenDetails: (row: any) => void;
  total: number;
}) {
  const router = useRouter();
  const pathname = usePathname();
  const sp = useSearchParams();

  const page = Math.max(1, parseInt(sp.get("page") ?? "1", 10));
  const limit = Math.max(1, parseInt(sp.get("limit") ?? "25", 10));
  const pages = Math.max(1, Math.ceil((total || 0) / limit));
  const sort: SortKey = ((sp.get("sort") as SortKey) || "created");
  const dir = (sp.get("dir") === "asc" ? "asc" : "desc");

  function setUrl(nextSort: SortKey) {
    const url = new URL(window.location.origin + pathname + "?" + sp.toString());
    const isSame = sort === nextSort;
    const nextDir = isSame ? (dir === "asc" ? "desc" : "asc") : "asc";
    url.searchParams.set("sort", nextSort);
    url.searchParams.set("dir", nextDir);
    url.searchParams.set("page", "1");
    router.replace(url.toString(), { scroll: false });
  }

  function setPage(next: number) {
    const url = new URL(window.location.origin + pathname + "?" + sp.toString());
    const n = Math.min(Math.max(1, next), pages);
    url.searchParams.set("page", String(n));
    router.replace(url.toString(), { scroll: false });
  }

  function Th({ label, col, className }: { label: string; col: SortKey; className?: string }) {
    const active = sort === col;
    return (
      <button
        type="button"
        onClick={(e) => { e.preventDefault(); e.stopPropagation(); setUrl(col); }}
        className={"w-full inline-flex items-center justify-center gap-1 hover:underline " + (className || "")}
        title={"Sort by " + label}
      >
        <span>{label}</span>
        {active ? (dir === "asc" ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />) : null}
      </button>
    );
  }

  if (loading) {
    return (
      <section className="rounded-2xl border bg-white p-6">
        <div className="text-sm text-neutral-600">Loading…</div>
      </section>
    );
  }

  if (!items || items.length === 0) {
    return (
      <section className="rounded-2xl border bg-white p-6">
        <div className="rounded-xl border bg-neutral-50 p-4 text-sm">
          No codes match your filters. Try adjusting search or filters.
        </div>
      </section>
    );
  }

  return (
    <section className="rounded-2xl border bg-white p-6 text-[13px] md:text-sm text-neutral-700">
      {/* Header: 4 cols on mobile, 6 cols on md+ */}
      <div className="grid grid-cols-4 md:grid-cols-6 rounded-xl bg-neutral-50 border border-neutral-200 text-xs font-medium text-neutral-600">
        <div className="text-center px-2 py-1.5"><Th label="Code" col="code" /></div>
        <div className="text-center px-2 py-1.5"><Th label="Type" col="type" /></div>
        <div className="text-center px-2 py-1.5"><Th label="Status" col="status" /></div>
        {/* Assigned (hidden on mobile) */}
        <div className="hidden md:block text-center px-2 py-1.5"><Th label="Assigned" col="assigned" /></div>
        {/* Created (hidden on mobile) */}
        <div className="hidden md:block text-center px-2 py-1.5"><Th label="Created" col="created" /></div>
        <div className="text-center px-2 py-1.5">Actions</div>
      </div>

      {/* Rows */}
      <div className="divide-y">
        {items.map((p) => (
          <div key={String(p.id)} className="grid grid-cols-4 md:grid-cols-6 items-center py-1.5">
            {/* Code + Copy */}
            <div className="text-center px-2 py-1.5 font-mono font-semibold break-words">
              <div className="inline-flex items-center gap-2">
                <span className="truncate max-w-[9ch] md:max-w-none">{p.code}</span>
                <button
                  type="button"
                  className="px-2 py-1 text-[11px] underline hover:no-underline focus:outline-none focus:ring-2 focus:ring-blue-200 rounded"
                  title="Copy code"
                  onClick={() => onCopy(p.code)}
                >
                  Copy
                </button>
              </div>
            </div>

            {/* Type (smaller chip) */}
            <div className="text-center px-2 py-1.5">
              <div className="inline-block text-xs"><TypeChip t={p.type} /></div>
            </div>

            {/* Status (smaller chip) */}
            <div className="text-center px-2 py-1.5">
              <div className="inline-block text-xs"><StatusChip s={p.status} /></div>
            </div>

            {/* Assigned (hide on mobile) */}
            <div className="hidden md:flex items-center justify-center px-2 py-1.5 whitespace-normal break-words text-center">
              {p.assigned_to_name || "—"}
            </div>

            {/* Created (hide on mobile) */}
            <div className="hidden md:flex items-center justify-center px-2 py-1.5 whitespace-normal break-words text-center">
              {p.created_at
                ? new Date(p.created_at).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" })
                : "—"}
            </div>

            {/* Actions */}
            <div className="flex items-center justify-end gap-1 px-2 py-1.5">
              {p.status === "consumed" ? (
                <button
                  type="button"
                  className="btn btn-ghost text-xs px-2 py-1 opacity-60 cursor-not-allowed no-underline hover:no-underline"
                  title="Consumed codes cannot be archived"
                  disabled
                >
                  Consumed
                </button>
              ) : p.status === "active" || p.status === "reserved" ? (
                <button
                  type="button"
                  className="btn btn-ghost text-xs px-2 py-1"
                  onClick={() => onToggleStatus(p.id, "archived")}
                >
                  Archive
                </button>
              ) : (
                <button
                  type="button"
                  className="btn btn-primary text-xs px-2 py-1"
                  onClick={() => onToggleStatus(p.id, "active")}
                >
                  Activate
                </button>
              )}

              <button
                type="button"
                className="btn btn-ghost inline-flex items-center justify-center p-2 ml-auto"
                title="Details"
                onClick={() => onOpenDetails(p)}
              >
                <Info className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Pagination */}
      <div className="mt-4 flex items-center justify-between text-xs md:text-sm">
        <div className="text-neutral-600">Page {page} of {pages}</div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            className="btn btn-ghost text-xs md:text-sm px-3 py-1.5"
            onClick={() => setPage(page - 1)}
            disabled={page <= 1}
          >
            Prev
          </button>
          <button
            type="button"
            className="btn btn-ghost text-xs md:text-sm px-3 py-1.5"
            onClick={() => setPage(page + 1)}
            disabled={page >= pages}
          >
            Next
          </button>
        </div>
      </div>
    </section>
  );
}
