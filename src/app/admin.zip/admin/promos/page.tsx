"use client";

import { useEffect, useMemo, useState, Suspense } from "react";
import { createClient } from "@supabase/supabase-js";
import toast, { Toaster } from "react-hot-toast";

// Sections
import Header from "./sections/Header";
import StatsStrip from "./sections/StatsStrip";
import FiltersBar from "./sections/FiltersBar";
import GeneratorForm from "./sections/GeneratorForm";
import ListTable from "./sections/ListTable";
import DetailsDrawer from "./sections/DetailsDrawer";

// Shared state (URL-synced; server-driven)
import { useAdminPromos, type Promo, type UsageRow } from "./hooks/useAdminPromos";

export const dynamic = 'force-dynamic';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

// Split into a child so we can wrap only the app with <Suspense>
function AdminPromosApp() {
  // --- Hook model: holds items/stats/filters and server calls ---
  const model = useAdminPromos();

  // --- Keep your existing auth guard behavior (redirect if no session) ---
  useEffect(() => {
    let alive = true;
    supabase.auth.getSession().then(({ data }) => {
      const token = data.session?.access_token || "";
      if (!token && alive) window.location.href = "/admin/login";
    });
    return () => { alive = false; };
  }, []);

  // --- Local-only UI state (unchanged) ---
  const [openId, setOpenId] = useState<string | number | null>(null);
  const [openRow, setOpenRow] = useState<Promo | null>(null);
  const [usage, setUsage] = useState<UsageRow[] | null>(null);
  const [usageLoading, setUsageLoading] = useState(false);

  const [genType, setGenType] = useState<""|"early_bird"|"artist"|"staff">("");
  const [qty, setQty] = useState(10);
  const [meta, setMeta] = useState({ name: "", email: "", phone: "", note: "" });
  const [genMsg, setGenMsg] = useState("");

  // ---- Handlers (same UX; now they call the hook methods) ----
  const onSearch = () => {
    model.onSearch(); // writes URL + fetches; keeps “Search-only” rule
  };

  const copyCode = async (code: string) => {
    try { await navigator.clipboard.writeText(code); toast.success("Code copied"); }
    catch { toast.error("Couldn’t copy"); }
  };

  const toggleStatus = async (id: string|number, to: "active"|"disabled") => {
    const res = await model.toggleStatus(id, to);
    if (res.ok) {
      const target = (to === "active" ? "active" : "archived");
      toast.success(target === "active" ? "Code activated" : "Code archived");
      try { await model.fetchList(); } catch {}

      // If the drawer is open for this id, update status + reload usage in place.
      setOpenRow((prev) => {
        if (!prev) return prev;
        if (String(prev.id) !== String(id)) return prev;
        return { ...prev, status: target as any };
      });

      if (openId && String(openId) === String(id)) {
        try {
          setUsageLoading(true);
          const { ok, items } = await model.loadUsage(id);
          setUsage(ok ? items : []);
        } catch { /* noop */ }
        finally { setUsageLoading(false); }
      }
    } else {
      toast.error("Update failed");
    }
  };

  const openDetails = async (row: Promo) => {
    setOpenRow(row); setOpenId(row.id); setUsage(null); setUsageLoading(true);
    const { ok, items } = await model.loadUsage(row.id);
    setUsage(ok ? items : []);
    if (!ok) toast.error("Failed to load history");
    setUsageLoading(false);
  };
  const closeDetails = () => { setOpenId(null); setOpenRow(null); setUsage(null); };

  const createCodes = async (e: React.FormEvent) => {
    e.preventDefault();
    setGenMsg("");
    if (!genType) { setGenMsg("Choose a promo type."); return; }
    const payload = {
      type: genType, quantity: qty,
      assigned_to_name: meta.name || null,
      assigned_email:  meta.email || null,
      assigned_phone:  meta.phone || null,
      note:            meta.note || null,
    };
    const { ok, data } = await model.createCodes(payload);
    if (!ok) {
      setGenMsg(data?.error || "Failed to create codes.");
      toast.error("Create failed");
      return;
    }
    const created = data?.count ?? 0;
    setGenMsg(`Created ${created} codes.`);
    toast.success(`Created ${created} code${created === 1 ? "" : "s"}`);
    model.fetchList();
  };

  // Visuals unchanged
  const filtered = useMemo(() => model.items, [model.items]);

  return (
    <main className="mx-auto max-w-5xl space-y-8 mt-8">
      <Toaster position="top-right" />

      <Header />

      <StatsStrip stats={model.stats} />

      <FiltersBar
        q={model.filters.q}
        type={model.filters.type}
        status={model.filters.status}
        used={model.filters.used}
        setQ={(v)=>model.setFilters({ q: v })}
        setType={(v)=>model.setFilters({ type: v as any })}
        setStatus={(v)=>model.setFilters({ status: v as any })}
        setUsed={(v)=>model.setFilters({ used: v as any })}
        onSearch={onSearch}
      />

      <GeneratorForm
        genType={genType} setGenType={setGenType}
        qty={qty} setQty={setQty}
        meta={meta} setMeta={setMeta}
        genMsg={genMsg}
        stats={model.stats}
          onQuickSubmit={async () => {
            // Create exactly 1 code (Quick Add)
            const res = await model.createCodes({
              type: genType,
              quantity: 1,
              assigned_to_name: (meta?.name || "").trim() || undefined
            });
            if (res?.ok) {
              const created = res?.data?.created || [];
              const code = created[0]?.code || "";
              // toast + refresh list+stats
              try { (await import("react-hot-toast")).default.success(`Created 1 ${genType === "early_bird" ? "Early Bird" : genType === "artist" ? "Artist" : "Staff"} code.`); } catch {}
              // Ensure latest data visible
              try { await model.fetchList(); } catch {}
              return code;
            } else {
              // Bubble up error object so child can render a friendly banner
              throw res?.data || { message: "Create failed" };
            }
          }}
          onBulkSubmit={async () => {
            const payload = {
              type: genType,
              quantity: qty,
              ...(meta?.name ? { assigned_to_name: meta.name.trim() } : {})
            };
            const res = await model.createCodes(payload);
            if (res?.ok) {
              const count = res?.data?.count ?? 0;
              try { (await import("react-hot-toast")).default.success(`Created ${count} ${genType === "early_bird" ? "Early Bird" : genType === "artist" ? "Artist" : "Staff"} codes.`); } catch {}
              try { await model.fetchList(); } catch {}
              return count;
            } else {
              throw res?.data || { message: "Create failed" };
            }
          }}
          onSubmit={createCodes}
      />

      <ListTable
        items={filtered}
        loading={model.loading}
        onCopy={copyCode}
        onToggleStatus={toggleStatus}
        onOpenDetails={openDetails}
      
        total={model.total}
      />

      {openId && openRow && (
        <DetailsDrawer
          row={openRow}
          usage={usage}
          usageLoading={usageLoading}
          onClose={closeDetails} onToggleStatus={(id,to)=>toggleStatus(id, to==="archived" ? "disabled" : "active")} onCopyCode={copyCode}
         />
      )}
    </main>
  );
}

export default function AdminPromosPage() {
  return (
    <Suspense fallback={<div className="rounded-xl border bg-neutral-50 p-4 text-sm">Loading…</div>}>
      <AdminPromosApp />
    </Suspense>
  );
}
