﻿import React from "react";

export default function StatsStrip({ stats }: { stats: any }) {
  return (
    <section className="rounded-2xl border bg-white p-6 space-y-4">
      <p className="text-neutral-700">Here’s the current promo code status</p>
      {!stats ? (
        <div className="text-sm text-neutral-600">Loading…</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 md:divide-x md:divide-neutral-200">

          {/* Early Bird */}
          <div className="px-0 md:pr-6">
            <div className="text-base text-neutral-700 font-medium">Early Bird codes</div>
            <div className="text-neutral-700">
              <span className="font-semibold">{stats.created.early_bird}</span> / {stats.caps.early_bird} created
            </div>
            <div className="text-neutral-600">
              <span className="font-semibold">{stats.used.early_bird}</span> / {stats.created.early_bird} used
            </div>
          </div>

          {/* Artist */}
          <div className="px-0 md:pr-6">
            <div className="text-base text-neutral-700 font-medium">Artist codes</div>
            <div className="text-neutral-700">
              <span className="font-semibold">{stats.created.artist}</span> / {stats.caps.artist} created
            </div>
            <div className="text-neutral-600">
              <span className="font-semibold">{stats.used.artist}</span> / {stats.created.artist} used
            </div>
          </div>

          {/* Staff */}
          <div className="px-0 md:pr-6">
            <div className="text-base text-neutral-700 font-medium">Staff codes</div>
            <div className="text-neutral-700">
              <span className="font-semibold">{stats.created.staff}</span> created
            </div>
            <div className="text-neutral-600">
              <span className="font-semibold">{stats.used.staff}</span> / {stats.created.staff} used
            </div>
          </div>

          {/* Total */}
          <div className="px-0">
            <div className="text-base text-neutral-700 font-medium">Total</div>
            <div className="text-neutral-700">
              <span className="font-semibold">{stats.created.total}</span> created so far
            </div>
            <div className="text-neutral-600">
              <span className="font-semibold">{stats.used.total}</span> / {stats.created.total} used so far
            </div>
          </div>

        </div>
      )}
    </section>
  );
}
